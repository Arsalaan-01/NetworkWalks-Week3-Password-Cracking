# Exercise 2 – Password Auditing with John the Ripper

## Objective
Learn the authorised PDF hash-auditing workflow using John the Ripper (JtR) and, where available, its Johnny graphical interface.

## Tools
- PDF hash-extraction utility specified by the lab
- John the Ripper (`john`)
- Johnny GUI (optional, if provided for the exercise)
- Supplied lab PDF
- Wordlist supplied or authorised by the lab

## Methodology
Fill in only the steps you personally completed:

1. Confirm the PDF is the file supplied for the authorised exercise.
2. Extract its password hash using the lab's specified utility.
3. Save the extracted hash in a local lab-only file.
4. Load the hash into John the Ripper or Johnny as instructed.
5. Run the authorised audit using the lab-provided configuration / wordlist.
6. Review the output and record the result.
7. Verify any recovered password against the supplied lab PDF.

Do not upload hash files, recovered passwords, wordlists containing private data, or challenge secrets to GitHub.

## Results
- Hash extraction: **[Add actual result]**
- JtR / Johnny run: **[Add actual result]**
- Cracked entries reported: **[Add actual count, if shown]**
- Verification: **[Add how you verified the result]**
- Challenge flag: **[Add only if personally obtained and permitted]**

## Screenshots
Add your own evidence in this folder.

| Evidence | Screenshot |
|---|---|
| Hash extraction | `screenshots/01-pdf-hash-extraction.png` |
| JtR / Johnny run | `screenshots/02-jtr-results.png` |
| Verification | `screenshots/03-verification.png` |

Delete rows for evidence you do not have.
