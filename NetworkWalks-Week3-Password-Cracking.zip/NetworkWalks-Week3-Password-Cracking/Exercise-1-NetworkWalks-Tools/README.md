# Exercise 1 – NetworkWalks Hash Calculator and Password Cracker

## Objective
Practise extracting a password hash from the PDF supplied for the authorised internship exercise and analysing it with the designated NetworkWalks tools.

## Tools
- NetworkWalks Hash Calculator
- NetworkWalks Password Cracker
- The supplied lab PDF
- Supported browser / operating system

## Methodology
Document the steps you actually performed:

1. Confirm that the PDF was supplied for this authorised lab.
2. Open the NetworkWalks Hash Calculator.
3. Select and submit the lab PDF according to the exercise instructions.
4. Record the hash-extraction result without publishing sensitive material.
5. Use the NetworkWalks Password Cracker as instructed by the lab.
6. Record the tool's output.
7. Verify any recovered password by opening only the supplied lab PDF.

## Results
- Hash extraction: **[Add your actual result]**
- Password-audit result: **[Add your actual result]**
- Verification: **[Explain how you verified it]**
- Challenge flag: **[Add only if personally obtained; do not publish secrets if prohibited]**

## Screenshots
Place your own screenshots in this folder and add them below.

| Evidence | Screenshot |
|---|---|
| Hash calculator input / extraction | `screenshots/01-hash-extraction.png` |
| Password cracker output | `screenshots/02-password-cracker.png` |
| Verification / challenge completion | `screenshots/03-verification.png` |

If a screenshot is not available, remove its row rather than implying it exists.

## Notes
Record any errors, limitations, operating-system differences or steps that did not work.
