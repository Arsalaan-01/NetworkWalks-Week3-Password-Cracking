# NetworkWalks Cybersecurity Internship – Week 3: Password Cracking

**Author:** Dar Arsalan  
**Topic:** PDF password hash extraction and password auditing  
**Status:** Practical evidence to be added

## Overview
This repository documents hands-on learning exercises involving password hash extraction and password auditing in an authorised lab environment. It is organised around two exercise tracks:

1. NetworkWalks Hash Calculator and Password Cracker
2. John the Ripper (JtR) / Johnny

> **Important:** This is a personal project template. Replace the evidence placeholders with screenshots and results from your own completed exercises. Do not claim a successful recovery or challenge flag unless you personally verified it.

## Objectives
- Understand the difference between a password and its stored hash.
- Learn how PDF password hashes can be extracted for authorised testing.
- Explore password-auditing workflows with the designated lab tools.
- Interpret tool output and verify results safely.
- Document methodology, evidence, limitations and lessons learned.

## Repository structure
```text
.
├── README.md
├── LICENSE
├── .gitignore
├── Exercise-1-NetworkWalks-Tools/
│   ├── README.md
│   └── screenshots/
├── Exercise-2-John-the-Ripper/
│   ├── README.md
│   └── screenshots/
└── Documentation/
    ├── Password-Hashing.md
    ├── Tools-Used.md
    └── Key-Learnings.md
```

## Exercise 1 – NetworkWalks tools
See [Exercise 1 documentation](Exercise-1-NetworkWalks-Tools/README.md).

## Exercise 2 – John the Ripper
See [Exercise 2 documentation](Exercise-2-John-the-Ripper/README.md).

## Concepts
- [Password hashing](Documentation/Password-Hashing.md)
- [Tools used](Documentation/Tools-Used.md)
- [Key learnings](Documentation/Key-Learnings.md)

## Evidence
Add genuine screenshots to the relevant `screenshots/` folders and reference them in the exercise READMEs. Blur personal information, tokens, account identifiers and unrelated data before publishing.

## Scope and responsible use
All testing must be limited to files, accounts and systems you own or have explicit permission to assess. This repository is for education and defensive password auditing. It is not a guide to accessing third-party accounts or documents.

## Acknowledgement
Add the correct internship, trainer and mentor acknowledgement here, using their preferred names and titles.
