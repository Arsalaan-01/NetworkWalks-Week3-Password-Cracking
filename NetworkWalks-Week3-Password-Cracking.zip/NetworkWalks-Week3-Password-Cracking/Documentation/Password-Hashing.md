# Password Hashing – Notes

A password hash is the output of a one-way cryptographic function applied to input data. Systems should store appropriately salted, slow password hashes rather than plaintext passwords.

## Hashing vs encryption
- **Hashing:** designed to be one-way; there is no normal decryption operation.
- **Encryption:** designed to be reversible with the appropriate key.

## Why password hashes are audited
A password audit checks whether passwords are weak or predictable. In an authorised lab, a candidate password may be tested against a supplied hash. A match indicates that the candidate corresponds to the password used to create that hash.

## Defensive lessons
- Use long, unique passwords.
- Use a password manager.
- Enable multi-factor authentication where possible.
- Store passwords using modern password-hashing schemes such as Argon2id, scrypt or bcrypt, configured appropriately.
- Never reuse passwords across services.
