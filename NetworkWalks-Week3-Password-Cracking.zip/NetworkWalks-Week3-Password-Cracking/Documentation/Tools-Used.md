# Tools Used

Complete this page with the exact versions and platforms you used.

| Tool | Purpose | Version / platform |
|---|---|---|
| NetworkWalks Hash Calculator | Extract hash from authorised lab PDF | [Fill in] |
| NetworkWalks Password Cracker | Lab password-auditing exercise | [Fill in] |
| John the Ripper | Password-hash auditing | [Fill in] |
| Johnny | Optional graphical interface for JtR | [Fill in] |
| PDF hash extractor | Extract PDF password hash | [Fill in exact tool] |

Do not list a tool as used unless you actually used it.
