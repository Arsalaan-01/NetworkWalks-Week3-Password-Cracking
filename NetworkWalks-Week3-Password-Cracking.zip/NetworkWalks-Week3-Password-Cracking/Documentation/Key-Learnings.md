# Key Learnings

Use this page as a reflection. Edit the prompts to match your experience.

## Technical concepts
- What a password hash represents.
- Why hash extraction is a separate step from password auditing.
- How a password-auditing tool reports progress and results.
- Why verification matters before reporting success.

## Practical challenges
- **Challenge faced:** [Describe a real issue]
- **How I approached it:** [Describe your steps]
- **What I learned:** [Describe the outcome]

## Defensive takeaways
- Use unique, long passwords.
- Prefer password managers and multi-factor authentication.
- Avoid insecure password storage.
- Conduct password audits only with explicit authorisation.
